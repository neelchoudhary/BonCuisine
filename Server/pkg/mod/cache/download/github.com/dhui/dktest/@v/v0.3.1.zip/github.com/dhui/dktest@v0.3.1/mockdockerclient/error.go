package mockdockerclient

import (
	"errors"
)

// Err is the canonical error returned by mocks
var Err = errors.New("mockdockerclient error")
