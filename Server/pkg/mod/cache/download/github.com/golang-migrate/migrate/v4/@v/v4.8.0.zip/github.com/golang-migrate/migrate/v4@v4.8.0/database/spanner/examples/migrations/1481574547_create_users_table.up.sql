CREATE TABLE Users (
  UserId  INT64,
  Name    STRING(40),
  Email   STRING(83)
) PRIMARY KEY(UserId)