ALTER TABLE users ADD city varchar(100);


