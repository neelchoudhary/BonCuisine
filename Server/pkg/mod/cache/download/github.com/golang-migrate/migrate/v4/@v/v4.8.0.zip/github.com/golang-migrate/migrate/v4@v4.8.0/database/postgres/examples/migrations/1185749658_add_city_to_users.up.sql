ALTER TABLE users ADD COLUMN city varchar(100);


