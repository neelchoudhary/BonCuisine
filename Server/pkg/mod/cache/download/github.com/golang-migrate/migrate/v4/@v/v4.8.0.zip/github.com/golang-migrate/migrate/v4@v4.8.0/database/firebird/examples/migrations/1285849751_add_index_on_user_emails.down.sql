DROP INDEX users_email_index;
